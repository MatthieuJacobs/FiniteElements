# FiniteElements
Git repository for project for Finite elements course

GROEP NUMMER 29
